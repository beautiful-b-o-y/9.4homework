use regex::Regex;
use std::env;
use std::fs;
use std::path::Path;
use std::process;
//use to modify the color of text
use std::io::{self};
use crossterm::execute;
use crossterm::style::{SetForegroundColor, ResetColor, Color};

fn main() -> io::Result<()>{
    let args: Vec<String> = env::args().collect();
    // println!("args[0]:{}",args[0]);
    // println!("args[1]:{}",args[1]);
    // println!("args[2]:{}",args[2]);
    if args.len() < 3{
        eprintln!("使用方式：{}<目标目录><要搜索的正则表达式>",args[0]);
        process::exit(1);
    }

    let pattern = &args[2];
    let regex = match Regex::new(pattern) {
        Ok(re) => re,
        Err(err) => {
            eprintln!("无效的正则表达式:'{}':{}",pattern,err);
            process::exit(1);
        }
    };

    match find(&args[1],&regex) {
        Ok(matches) => {
            if matches.is_empty(){
                println!("未找到匹配项。");
            }else {
                println!("找到以下匹配项：");
                let num_steps = matches.len();
                let mut num=1;
                for file in matches {
                    //设置一个由红到蓝的渐变色
                    let fore_color = Color::Rgb{
                        r:lerp(255,0,num,num_steps),
                        g:lerp(0,0,num,num_steps),
                        b:lerp(0,255,num,num_steps),
                    };
                    execute!(
                        io::stdout(),
                        SetForegroundColor(fore_color),
                    )?;
                    println!("{}",file);
                    execute!(
                        io::stdout(),
                        ResetColor,
                    )?;
                    num = num + 1;
                }
            }
        }
        Err(error) => {
            eprintln!("发生错误:{}",error);
            process::exit(1);
        }
    }
    Ok(())
}

fn find<P: AsRef<Path>>(root: P, regex: &Regex) -> Result<Vec<String>, Box<dyn std::error::Error>>{
    let mut matches = Vec::new( );
    walk_tree(root .as_ref(), regex, &mut matches )?;
    Ok(matches)
}

fn walk_tree(
    dir: &Path,
    regex: &Regex,
    matches: &mut Vec<String>,
) ->Result<(), Box<dyn std::error::Error>>{
    if dir.is_dir() {
        for entry in fs::read_dir(dir)?{
            let entry = entry?;
            let path = entry.path( );
            if path.is_dir(){
                walk_tree(&path, regex, matches)?;
            }else if let Some(filename) = path.file_name( ).and_then(|s| s.to_str()){
                if regex.is_match( filename ) {
                    matches.push(path.to_string_lossy().to_string());
                }
            }
        }
    }
    Ok(())
}

fn lerp(start:u8,end:u8,step:usize,num_steps:usize)->u8{
    let t = step as f32 / num_steps as f32;
    ((1.0 - t) * f32::from(start) + t * f32::from(end)) as u8
}